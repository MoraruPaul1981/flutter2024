
import 'package:flutter/foundation.dart';



import 'package:http/http.dart' as http;
import 'package:http/http.dart';



abstract  class InAdressJboss {
  String? adressJboss( {required String JobForServer, required int IdUser,required int VersionData} ) ;
}


abstract  class InAdress1C {
  String? adress1C() ;
}







