


import 'package:http/http.dart';



abstract  class  InParserJson1c {



  List<dynamic> getList1cDynamic({ required Response response1C}) ;

   String  getPingDynamicDontaunt({ required Response response1C}) ;

}















