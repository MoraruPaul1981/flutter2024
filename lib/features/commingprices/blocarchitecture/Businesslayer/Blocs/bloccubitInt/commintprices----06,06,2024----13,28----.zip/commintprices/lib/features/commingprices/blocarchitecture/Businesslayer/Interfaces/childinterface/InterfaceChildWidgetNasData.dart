




import 'package:flutter/cupertino.dart';
import 'package:logger/logger.dart';

abstract class InterfaceChildWidgetNasData  {
 late BuildContext context;
 late Logger logger;
 Key? key;

 void theServeristurnedRereceive() ;


}