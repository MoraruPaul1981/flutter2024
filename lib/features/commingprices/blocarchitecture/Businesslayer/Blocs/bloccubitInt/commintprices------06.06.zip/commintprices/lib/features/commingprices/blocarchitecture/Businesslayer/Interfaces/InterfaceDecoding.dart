
import 'dart:typed_data';

import 'package:http/http.dart';
import 'package:logger/logger.dart';


abstract  class InterfaceDecoding {

  //todo  dynamic Ping
  String getResponseDecoderPing({required  Response response1C});

  //todo  dynamic Sekf DatA
  List  getResponseDecoderSelfData({required  Response response1C,required Logger logger});


}