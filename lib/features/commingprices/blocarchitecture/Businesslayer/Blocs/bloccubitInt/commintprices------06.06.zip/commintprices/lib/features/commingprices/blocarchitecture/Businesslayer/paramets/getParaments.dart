

import 'package:http/http.dart';
import 'package:logger/logger.dart';

class GetParamentsPing {

    Response get GETResponse => (backresponsejboss);
        Logger get GETlogger => (logger);


         Response  backresponsejboss;
         Logger logger;
GetParamentsPing(this.backresponsejboss, this. logger);
}