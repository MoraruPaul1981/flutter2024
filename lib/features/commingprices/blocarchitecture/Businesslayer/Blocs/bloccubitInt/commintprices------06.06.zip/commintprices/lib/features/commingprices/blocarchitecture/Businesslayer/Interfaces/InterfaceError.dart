
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';



import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:logger/logger.dart';


abstract  class InterfaceError {

//TODO: writerError
  void writerError( {required Exception e, required StackTrace stacktrace  } ) ;

//TODO: writerError
  void writerErrorBig(BuildContext  context,  Logger logger,  {required Exception e, required StackTrace stacktrace}      ) ;


}







