
import 'package:flutter/foundation.dart';



import 'package:http/http.dart' as http;
import 'package:http/http.dart';

abstract  class InterfaceDCI {
  //TODO:
  setupSingleton( );

}








