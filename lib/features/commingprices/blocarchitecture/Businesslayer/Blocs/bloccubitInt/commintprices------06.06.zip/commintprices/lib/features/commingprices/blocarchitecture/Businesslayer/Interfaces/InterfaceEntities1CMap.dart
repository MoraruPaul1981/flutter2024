
import 'dart:collection';

import '../../Datalayer/entities/Entities1CMap.dart';








abstract  class InterfaceEntities1CMap {
 //Todo
  Map<String, List<Entities1CMap>> loopGeneratorMapPolo({required Map<String, dynamic> json } );


}




